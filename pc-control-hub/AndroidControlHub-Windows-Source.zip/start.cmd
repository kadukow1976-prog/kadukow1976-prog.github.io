@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 src\app.py
  goto :end
)
where python >nul 2>nul
if %errorlevel% equ 0 (
  python src\app.py
  goto :end
)
echo Python 3.10+ not found. Install Python from https://www.python.org/downloads/windows/
echo Or download Windows EXE build from the GitHub Release.
pause
:end
