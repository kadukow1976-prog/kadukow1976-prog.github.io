@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 goto :run
where python >nul 2>nul
if not errorlevel 1 goto :runpython
echo Python 3 was not found. To run Android Control Hub, Python must be installed.
echo.
echo You can install Python via winget from a verified community manifest.
where winget >nul 2>nul
if errorlevel 1 (
  echo winget is unavailable. Download Python from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
choice /C YN /M "Install Python 3.13 using winget"
if errorlevel 2 exit /b 1
winget install --id Python.Python.3.13 --exact --source winget --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
  echo Python installation failed. Download from python.org and try again.
  pause
  exit /b 1
)
echo Installation completed. Close this window and run INSTALL-AND-RUN.cmd again.
pause
exit /b 0
:run
py -3 src\app.py
exit /b %errorlevel%
:runpython
python src\app.py
exit /b %errorlevel%
