@echo off
setlocal
cd /d "%~dp0"
echo ====================================================
echo   Android Control Hub - Build standalone Windows EXE
echo ====================================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher not found. Install Python 3.10+ from https://www.python.org/downloads/windows/
  echo Make sure Add Python to PATH is selected.
  pause
  exit /b 1
)
py -3 -m unittest discover -s tests -v
if errorlevel 1 (
  echo Tests failed. EXE was not built.
  pause
  exit /b 1
)
echo.
echo Install PyInstaller from Python Package Index?
choice /C YN /M "Continue"
if errorlevel 2 exit /b 1
py -3 -m pip install --disable-pip-version-check pyinstaller==6.16.0
if errorlevel 1 (
  echo PyInstaller installation failed.
  pause
  exit /b 1
)
py -3 -m PyInstaller --clean --noconfirm --onefile --windowed --name AndroidControlHub --paths src src\app.py
if errorlevel 1 (
  echo EXE build failed.
  pause
  exit /b 1
)
echo.
echo READY: dist\AndroidControlHub.exe
echo You can copy this EXE to another Windows 10/11 computer.
pause
