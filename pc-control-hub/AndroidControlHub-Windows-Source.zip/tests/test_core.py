import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from ach_core import Service, ServiceError, FILE_FOLDERS


class FakeADB:
    def __init__(self, authorized=True, cache_supported=True):
        self.calls = []
        self.authorized = authorized
        self.cache_supported = cache_supported

    def __call__(self, argv, timeout):
        self.calls.append((argv, timeout))
        args = argv[1:]
        if args[:2] == ["devices", "-l"]:
            return SimpleNamespace(returncode=0, stdout="List of devices attached\nABC123 " +
                                   ("device" if self.authorized else "unauthorized") + " product:p model:Pixel\n", stderr="")
        if args[:3] == ["-s", "ABC123", "shell"]:
            shell = args[3:]
            if shell == ["pm", "list", "packages", "-3"]:
                result = "package:com.demo.app\npackage:com.example.chat\n"
            elif shell == ["am", "get-current-user"]:
                result = "0\n"
            elif shell == ["pm", "help"]:
                result = "pm clear [--cache-only]" if self.cache_supported else "pm clear PACKAGE"
            elif shell[:2] == ["pm", "clear"]:
                result = "Success\n"
            elif shell[:2] == ["pm", "uninstall"]:
                result = "Success\n"
            elif shell[:2] == ["pm", "disable-user"]:
                result = "Package com.demo.app new state: disabled-user\n"
            elif shell[:2] == ["pm", "enable"]:
                result = "Package com.demo.app new state: enabled\n"
            elif shell[:2] == ["pm", "path"]:
                result = "package:/data/app/com.demo.app/base.apk\n"
            else:
                result = ""
            return SimpleNamespace(returncode=0, stdout=result, stderr="")
        return SimpleNamespace(returncode=0, stdout="Success\n", stderr="")


class CoreTests(unittest.TestCase):
    def make_service(self, fake=None):
        fake = fake or FakeADB()
        obj = Service(adb=__file__, fastboot=__file__, runner=fake)
        obj.serial = "ABC123"
        return obj, fake

    def test_authorization_is_required(self):
        svc, fake = self.make_service(FakeADB(authorized=False))
        with self.assertRaisesRegex(ServiceError, "отладка не авторизована"):
            svc.third_party_packages()
        self.assertEqual(len(fake.calls), 1)

    def test_cache_uses_cache_only_flag(self):
        svc, fake = self.make_service()
        self.assertIn("Success", svc.maintenance("com.demo.app", "cache"))
        calls = [args for args, timeout in fake.calls]
        self.assertTrue(any(args[-7:] == ["shell", "pm", "clear", "--user", "0", "--cache-only", "com.demo.app"]
                            for args in calls), calls)

    def test_cache_unsupported_never_clears_data(self):
        svc, fake = self.make_service(FakeADB(cache_supported=False))
        with self.assertRaisesRegex(ServiceError, "НЕ запускается"):
            svc.maintenance("com.demo.app", "cache")
        self.assertFalse(any("clear" in args for args, _ in fake.calls))

    def test_protects_system_packages(self):
        svc, fake = self.make_service()
        for package in ["com.android.settings", "com.google.android.gms", "android", "com.oplus.telephony"]:
            with self.assertRaises(ServiceError):
                svc.maintenance(package, "data")
        self.assertEqual(len(fake.calls), 0)

    def test_only_installed_third_party_packages(self):
        svc, fake = self.make_service()
        with self.assertRaisesRegex(ServiceError, "не является пользовательским"):
            svc.maintenance("com.not.installed", "data")
        self.assertFalse(any("clear" in args for args, _ in fake.calls))

    def test_force_stop(self):
        svc, fake = self.make_service()
        svc.maintenance("com.demo.app", "stop")
        self.assertTrue(any(args[-6:] == ["shell", "am", "force-stop", "--user", "0", "com.demo.app"]
                            for args, _ in fake.calls))

    def test_uninstall_current_user(self):
        svc, fake = self.make_service()
        svc.maintenance("com.demo.app", "uninstall")
        self.assertTrue(any(args[-6:] == ["shell", "pm", "uninstall", "--user", "0", "com.demo.app"]
                            for args, _ in fake.calls))

    def test_bad_package_cannot_be_injected(self):
        svc, fake = self.make_service()
        for package in ["com.demo.app;rm", "com.demo.app && reboot", "-x", "com.demo.app\nreboot", "com.demo.a/b"]:
            with self.assertRaises(ServiceError):
                svc.maintenance(package, "data")
        self.assertFalse(fake.calls)

    def test_remote_pull_is_whitelisted(self):
        svc, fake = self.make_service()
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ServiceError):
                svc.pull_folder("/data/data", folder)
            svc.pull_folder(FILE_FOLDERS["Фото камеры"], folder)
            self.assertTrue(any("pull" in args for args, _ in fake.calls))

    def test_inventory_has_no_credentials(self):
        svc, fake = self.make_service()
        with tempfile.TemporaryDirectory() as folder:
            filename = Path(folder) / "inventory.json"
            n = svc.export_inventory(str(filename))
            self.assertEqual(n, 2)
            data = filename.read_text(encoding="utf-8")
            self.assertIn("com.demo.app", data)
            self.assertNotIn("password\":", data)


if __name__ == "__main__":
    unittest.main()
