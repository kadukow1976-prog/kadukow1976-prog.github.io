"""ADB/Fastboot service backend. No root, bypassing locks, or hidden operations."""
from __future__ import annotations

import json
import io
import urllib.request
import zipfile
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

PACKAGE_RE = re.compile(r"^[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)+$")
SERIAL_RE = re.compile(r"^[A-Za-z0-9_.:\-]+$")
SYSTEM_PREFIXES = ("android", "com.android.", "com.google.android.", "com.qualcomm.",
                   "com.oplus.", "com.oneplus.", "com.mediatek.", "com.samsung.android.",
                   "com.miui.", "com.xiaomi.")
OWN_PKG = "ru.kadukov.androidcontrolhub"
FILE_FOLDERS = {"Фото камеры": "/sdcard/DCIM", "Изображения": "/sdcard/Pictures",
                "Загрузки": "/sdcard/Download", "Документы": "/sdcard/Documents",
                "Видео": "/sdcard/Movies", "Музыка": "/sdcard/Music",
                "Медиа мессенджеров": "/sdcard/Android/media"}


class ServiceError(RuntimeError):
    pass


@dataclass(frozen=True)
class Device:
    serial: str
    status: str
    detail: str = ""
    def __str__(self):
        return f"{self.serial}  [{self.status}]  {self.detail}".strip()


@dataclass
class Result:
    args: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str
    @property
    def combined(self):
        return (self.stdout + "\n" + self.stderr).strip()


def config_root() -> Path:
    root = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "AndroidControlHub"
    root.mkdir(parents=True, exist_ok=True)
    return root


class Service:
    def __init__(self, adb: str = "", fastboot: str = "", runner: Callable | None = None):
        self.adb = adb
        self.fastboot = fastboot
        self.serial = ""
        self._runner = runner or self._subprocess_run
        self.log_callback: Callable[[str], None] | None = None

    @staticmethod
    def _subprocess_run(argv, timeout):
        kw = {"capture_output": True, "text": True, "errors": "replace", "timeout": timeout,
              "stdin": subprocess.DEVNULL}
        if sys.platform == "win32":
            kw["creationflags"] = subprocess.CREATE_NO_WINDOW
        return subprocess.run(argv, **kw)

    def _tool(self, which: str) -> str:
        candidate = self.adb if which == "adb" else self.fastboot
        if candidate and Path(candidate).is_file():
            return candidate
        if candidate and not Path(candidate).is_file():
            raise ServiceError(f"Не найден файл {which}: {candidate}")
        found = shutil.which(which)
        if not found:
            raise ServiceError(f"{which.upper()} не найден. Выберите путь к platform-tools или установите Android Platform Tools.")
        return found

    def run(self, tool: str, arguments: list[str], *, timeout: int = 30, check: bool = True) -> Result:
        exe = self._tool(tool)
        argv = [exe] + [str(a) for a in arguments]
        try:
            process = self._runner(argv, timeout)
        except subprocess.TimeoutExpired as exc:
            raise ServiceError(f"Превышено ожидание {timeout} с: {tool} {arguments[0] if arguments else ''}") from exc
        except OSError as exc:
            raise ServiceError(f"Ошибка запуска {tool}: {exc}") from exc
        result = Result(tuple(argv), int(process.returncode), process.stdout or "", process.stderr or "")
        if check and result.returncode:
            raise ServiceError(f"Ошибка {tool} (код {result.returncode}): {result.combined[:1000]}")
        return result

    def install_platform_tools(self) -> tuple[str, str]:
        """Download ONLY Google's official Windows platform-tools after explicit UI consent."""
        url = "https://dl.google.com/android/repository/platform-tools-latest-windows.zip"
        try:
            with urllib.request.urlopen(url, timeout=90) as response:
                if not response.url.startswith("https://dl.google.com/"):
                    raise ServiceError("Источник загрузки инструментов не совпадает с Google")
                content = response.read(75 * 1024 * 1024 + 1)
                if len(content) > 75 * 1024 * 1024:
                    raise ServiceError("Архив платформенных инструментов слишком большой")
        except (OSError, TimeoutError, ValueError) as exc:
            raise ServiceError(f"Не удалось получить Platform Tools от Google: {exc}") from exc
        root = config_root() / "platform-tools"
        wanted = {"adb.exe", "fastboot.exe", "AdbWinApi.dll", "AdbWinUsbApi.dll"}
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                members = {}
                for info in archive.infolist():
                    if info.filename.startswith("platform-tools/"):
                        leaf = info.filename[len("platform-tools/"):]
                        if leaf in wanted and not info.is_dir() and info.file_size < 30 * 1024 * 1024:
                            members[leaf] = info
                if not {"adb.exe", "fastboot.exe", "AdbWinApi.dll", "AdbWinUsbApi.dll"}.issubset(members):
                    raise ServiceError("Архив Google не содержит необходимые файлы ADB/Fastboot")
                root.mkdir(parents=True, exist_ok=True)
                for name, info in members.items():
                    target = root / name
                    temp = root / (name + ".tmp")
                    temp.write_bytes(archive.read(info))
                    os.replace(temp, target)
        except (OSError, zipfile.BadZipFile) as exc:
            raise ServiceError(f"Ошибка установки Platform Tools: {exc}") from exc
        self.adb = str(root / "adb.exe")
        self.fastboot = str(root / "fastboot.exe")
        return self.adb, self.fastboot

    def devices(self) -> list[Device]:
        output = self.run("adb", ["devices", "-l"], timeout=20).stdout
        records = []
        for line in output.splitlines():
            line = line.strip()
            if not line or line.lower().startswith("list of devices") or line.startswith("*"):
                continue
            cells = line.split()
            if len(cells) >= 2 and SERIAL_RE.fullmatch(cells[0]):
                records.append(Device(cells[0], cells[1], " ".join(cells[2:])))
        return records

    def fastboot_devices(self) -> list[Device]:
        output = self.run("fastboot", ["devices"], timeout=20).combined
        result = []
        for line in output.splitlines():
            cells = line.strip().split()
            if len(cells) >= 2 and SERIAL_RE.fullmatch(cells[0]) and cells[1] == "fastboot":
                result.append(Device(cells[0], "fastboot"))
        return result

    def use(self, serial: str):
        if not SERIAL_RE.fullmatch(serial):
            raise ServiceError("Неверный идентификатор устройства")
        states = {d.serial: d.status for d in self.devices()}
        if states.get(serial) != "device":
            raise ServiceError(f"Устройство не авторизовано: {states.get(serial, 'не подключено')}. Подтвердите отладку на телефоне.")
        self.serial = serial

    def _device(self):
        if not self.serial:
            raise ServiceError("Выберите телефон в состоянии device")
        states = {d.serial: d.status for d in self.devices()}
        if states.get(self.serial) != "device":
            raise ServiceError("Телефон отключён или отладка не авторизована. Повторите подключение.")
        return self.serial

    def adb_command(self, *arguments: str, timeout: int = 35, check=True) -> Result:
        return self.run("adb", ["-s", self._device(), *arguments], timeout=timeout, check=check)

    def shell(self, *arguments: str, timeout: int = 35, check=True) -> str:
        return self.adb_command("shell", *arguments, timeout=timeout, check=check).combined

    def user_id(self) -> str:
        text = self.shell("am", "get-current-user").strip()
        match = re.fullmatch(r"(?:Current user:\s*)?(\d{1,4})", text)
        if not match:
            raise ServiceError(f"Не удалось определить профиль Android: {text[:150]}")
        return match.group(1)

    @staticmethod
    def valid_package(package: str):
        if not PACKAGE_RE.fullmatch(package) or len(package) > 200:
            raise ServiceError("Некорректное имя пакета")
        if package == OWN_PKG or package == "android" or package.startswith(SYSTEM_PREFIXES):
            raise ServiceError("Защищённый пакет: эта операция запрещена")

    def third_party_packages(self) -> list[str]:
        return sorted({line.removeprefix("package:").strip() for line in
                       self.shell("pm", "list", "packages", "-3").splitlines()
                       if line.startswith("package:")})

    def check_user_app(self, package: str):
        self.valid_package(package)
        if package not in self.third_party_packages():
            raise ServiceError("Пакет не является пользовательским. Операция отменена.")

    def get_basic_report(self) -> dict[str, str]:
        props = {"Производитель": "ro.product.manufacturer", "Модель": "ro.product.model",
                 "Android": "ro.build.version.release", "API": "ro.build.version.sdk",
                 "Сборка": "ro.build.display.id", "SoC": "ro.soc.model", "ABI": "ro.product.cpu.abi",
                 "Патч безопасности": "ro.build.version.security_patch"}
        report = {k: self.shell("getprop", v).strip() for k, v in props.items()}
        report["Заряд и питание"] = self.shell("dumpsys", "battery")[:4500]
        report["Оперативная память"] = self.shell("cat", "/proc/meminfo")[:2500]
        report["Накопитель"] = self.shell("df", "-h", "/data")[:1300]
        report["USB ID"] = self.serial
        report["Время отчёта"] = time.strftime("%Y-%m-%d %H:%M:%S")
        return report

    def package_details(self, package: str) -> str:
        if not PACKAGE_RE.fullmatch(package):
            raise ServiceError("Неверное имя пакета")
        raw = self.shell("dumpsys", "package", package, timeout=45)
        pattern = re.compile(r"(?:versionName|versionCode|firstInstallTime|lastUpdateTime|targetSdk|userId|requested permissions|android.permission.SYSTEM_ALERT_WINDOW|android.permission.RECEIVE_BOOT_COMPLETED|android.permission.SCHEDULE_EXACT_ALARM|android.permission.FOREGROUND_SERVICE).*", re.I)
        lines = [line.strip() for line in raw.splitlines() if pattern.search(line)]
        return "\n".join(lines[:90]) if lines else "Система не предоставила подробности"

    def list_overlay_candidates(self, apps: list[str], progress=None) -> tuple[set[str], set[str]]:
        overlays, autostarts = set(), set()
        for index, package in enumerate(apps):
            try:
                raw = self.shell("dumpsys", "package", package, timeout=30)
                # Manifest-declared capability is a diagnostic signal, not proof of intrusive ads.
                if "android.permission.SYSTEM_ALERT_WINDOW" in raw:
                    overlays.add(package)
                if "android.permission.RECEIVE_BOOT_COMPLETED" in raw:
                    autostarts.add(package)
            except ServiceError:
                pass
            if progress and (index % 5 == 0 or index == len(apps) - 1):
                progress(index + 1, len(apps))
        return overlays, autostarts

    def maintenance(self, package: str, action: str) -> str:
        self.check_user_app(package)
        user = self.user_id()
        if action == "cache":
            if "--cache-only" not in self.shell("pm", "help"):
                raise ServiceError("Android не поддерживает --cache-only. Полная очистка НЕ запускается.")
            out = self.shell("pm", "clear", "--user", user, "--cache-only", package, timeout=60)
        elif action == "data":
            out = self.shell("pm", "clear", "--user", user, package, timeout=60)
        elif action == "disable":
            out = self.shell("pm", "disable-user", "--user", user, package)
        elif action == "enable":
            out = self.shell("pm", "enable", "--user", user, package)
        elif action == "stop":
            out = self.shell("am", "force-stop", "--user", user, package)
        elif action == "uninstall":
            out = self.shell("pm", "uninstall", "--user", user, package, timeout=70)
        else:
            raise ServiceError("Неподдерживаемая операция")
        if action not in ("stop",) and not any(s in out.lower() for s in ("success", "new state:", "already")):
            raise ServiceError(f"Android не подтвердил операцию: {out[:500]}")
        return out or "Команда выполнена без текстового вывода"

    def install_apk(self, paths: list[str]) -> str:
        if not paths or any(not Path(p).is_file() or Path(p).suffix.lower() != ".apk" for p in paths):
            raise ServiceError("Выберите существующие APK-файлы")
        command = "install" if len(paths) == 1 else "install-multiple"
        return self.adb_command(command, "-r", *paths, timeout=240).combined

    def export_apk(self, package: str, folder: str) -> list[str]:
        # Reads only publicly accessible package APK paths. No user application data.
        if not PACKAGE_RE.fullmatch(package):
            raise ServiceError("Некорректный идентификатор пакета")
        raw = self.shell("pm", "path", package)
        paths = [line.removeprefix("package:").strip() for line in raw.splitlines() if line.startswith("package:")]
        if not paths:
            raise ServiceError("Android не предоставил путь APK")
        target = Path(folder).resolve() / package
        target.mkdir(parents=True, exist_ok=True)
        saved = []
        for n, source in enumerate(paths, 1):
            dest = target / ("base.apk" if n == 1 else f"split-{n}.apk")
            self.adb_command("pull", source, str(dest), timeout=180)
            saved.append(str(dest))
        return saved

    def pull_folder(self, remote: str, target_dir: str) -> str:
        if remote not in FILE_FOLDERS.values():
            raise ServiceError("Недопустимый каталог. Выберите категорию из списка.")
        target = Path(target_dir).resolve()
        target.mkdir(parents=True, exist_ok=True)
        return self.adb_command("pull", remote, str(target), timeout=1200).combined

    def push_files(self, paths: list[str]) -> list[str]:
        if not paths or any(not Path(p).is_file() for p in paths):
            raise ServiceError("Выберите существующие файлы")
        self.shell("mkdir", "-p", "/sdcard/Download/AndroidControlHub")
        out = []
        for item in paths:
            name = Path(item).name
            if name in ("", ".", "..") or "/" in name or "\\" in name:
                raise ServiceError("Недопустимое имя файла")
            out.append(self.adb_command("push", item, "/sdcard/Download/AndroidControlHub/" + name, timeout=600).combined)
        return out

    def export_inventory(self, path: str):
        data = {"created": time.strftime("%Y-%m-%d %H:%M:%S"), "serial": self.serial,
                "note": "Список пакетов. Пароли и закрытые данные приложений НЕ включены.",
                "packages": self.third_party_packages()}
        Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return len(data["packages"])

    def fastboot_summary(self) -> str:
        devices = self.fastboot_devices()
        if not devices:
            raise ServiceError("Устройств Fastboot не обнаружено")
        lines = [f"Fastboot: {d.serial}" for d in devices]
        for key in ("product", "current-slot", "unlocked", "secure"):
            try:
                value = self.run("fastboot", ["-s", devices[0].serial, "getvar", key], timeout=15, check=False)
                lines.append(f"{key}: {value.combined[-500:]}")
            except ServiceError as exc:
                lines.append(f"{key}: недоступно ({exc})")
        return "\n".join(lines)
