"""Android Control Hub — Windows workstation for owner-authorized Android maintenance."""
from __future__ import annotations

import json
import os
import sys
import threading
import time
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk
from urllib.parse import quote
import webbrowser

from ach_core import Service, ServiceError, FILE_FOLDERS, config_root

TITLE = "Android Control Hub · Windows Service Center"
VERSION = "0.1.0"
BG = "#0B1220"
CARD = "#132237"
BORDER = "#293C52"
TEXT = "#EAF4FB"
MUTED = "#9CAFC1"
ACCENT = "#4FE2B1"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{TITLE} {VERSION}")
        self.geometry("1150x790")
        self.minsize(900, 620)
        self.configure(bg=BG)
        self.config_path = config_root() / "settings.json"
        try:
            config = json.loads(self.config_path.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            config = {}
        self.adb_path = tk.StringVar(value=config.get("adb", ""))
        self.fastboot_path = tk.StringVar(value=config.get("fastboot", ""))
        self.device_name = tk.StringVar(value="Не подключено")
        self.search_value = tk.StringVar()
        self.state_value = tk.StringVar(value="Готово к подключению")
        self.service = Service(self.adb_path.get(), self.fastboot_path.get())
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="ach-background")
        self.running = False
        self.devices_map = {}
        self.current_packages: list[str] = []
        self.flagged_overlays: set[str] = set()
        self.flagged_boot: set[str] = set()
        self.log_lines: list[str] = []
        self.configure_styles()
        self.build_ui()
        self.search_value.trace_add("write", lambda *_: self.render_packages())
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.after(350, self.refresh_devices)

    def configure_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background=BG)
        style.configure("Panel.TFrame", background=CARD)
        style.configure("TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 10))
        style.configure("Muted.TLabel", background=BG, foreground=MUTED, font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=BG, foreground=TEXT, font=("Segoe UI Semibold", 21))
        style.configure("Header.TLabel", background=BG, foreground=ACCENT, font=("Segoe UI Semibold", 11))
        style.configure("TButton", padding=(13, 9), foreground=TEXT, background="#233A50", borderwidth=0,
                        font=("Segoe UI", 9))
        style.map("TButton", background=[("active", "#33526E"), ("disabled", "#172535")],
                  foreground=[("disabled", "#6C7C8C")])
        style.configure("Accent.TButton", foreground="#102B27", background=ACCENT,
                        font=("Segoe UI Semibold", 9))
        style.map("Accent.TButton", background=[("active", "#65F0C0"), ("disabled", "#51746F")])
        style.configure("TEntry", fieldbackground="#192B3E", foreground=TEXT, insertcolor=TEXT, padding=7)
        style.configure("TCombobox", fieldbackground="#192B3E", foreground=TEXT, background="#192B3E", padding=5)
        style.map("TCombobox", fieldbackground=[("readonly", "#192B3E")], foreground=[("readonly", TEXT)])
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(19, 12), font=("Segoe UI Semibold", 10),
                        background="#172639", foreground=MUTED)
        style.map("TNotebook.Tab", background=[("selected", CARD)], foreground=[("selected", ACCENT)])
        style.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=TEXT,
                        rowheight=29, font=("Segoe UI", 9), borderwidth=0)
        style.configure("Treeview.Heading", background="#1D3348", foreground=ACCENT,
                        font=("Segoe UI Semibold", 9))
        style.map("Treeview", background=[("selected", "#2E5364")], foreground=[("selected", "#FFFFFF")])
        style.configure("Vertical.TScrollbar", background="#22384C", troughcolor=BG)

    def build_ui(self):
        header = ttk.Frame(self, padding=(24, 17))
        header.pack(fill="x")
        ttk.Label(header, text="ANDROID CONTROL HUB", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="  WINDOWS  •  SERVICE CENTER  v" + VERSION,
                  style="Header.TLabel").pack(side="left", padx=14)
        ttk.Button(header, text="Проверить устройства", style="Accent.TButton",
                   command=self.refresh_devices).pack(side="right")

        select = ttk.Frame(self, padding=(24, 0, 24, 13))
        select.pack(fill="x")
        ttk.Label(select, text="Активное устройство:").pack(side="left")
        self.device_combo = ttk.Combobox(select, textvariable=self.device_name, state="readonly", width=55)
        self.device_combo.pack(side="left", padx=12)
        self.device_combo.bind("<<ComboboxSelected>>", lambda _event: self.select_device())
        ttk.Button(select, text="ADB / Fastboot — путь", command=self.tools_dialog).pack(side="left")
        ttk.Button(select, text="Установить ADB автоматически", command=self.install_tools).pack(side="left", padx=8)
        ttk.Button(select, text="Сайт Google", command=lambda: webbrowser.open(
            "https://developer.android.com/tools/releases/platform-tools")).pack(side="left", padx=8)

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=24, pady=(0, 6))
        self.t_overview = ttk.Frame(self.tabs, padding=17)
        self.t_apps = ttk.Frame(self.tabs, padding=17)
        self.t_files = ttk.Frame(self.tabs, padding=17)
        self.t_tools = ttk.Frame(self.tabs, padding=17)
        self.t_log = ttk.Frame(self.tabs, padding=17)
        for page, label in ((self.t_overview, "Диагностика"), (self.t_apps, "Приложения"),
                            (self.t_files, "Файлы и бэкап"), (self.t_tools, "Установка / Fastboot"),
                            (self.t_log, "Журнал")):
            self.tabs.add(page, text=label)
        self.build_overview()
        self.build_apps()
        self.build_files()
        self.build_tools()
        self.build_log()
        bottom = ttk.Frame(self, padding=(24, 8, 24, 11))
        bottom.pack(fill="x")
        ttk.Label(bottom, textvariable=self.state_value, style="Muted.TLabel").pack(side="left")
        ttk.Label(bottom, text="ADB требует разблокировки и разрешения отладки на телефоне. Root не нужен.",
                  style="Muted.TLabel").pack(side="right")

    def build_overview(self):
        bar = ttk.Frame(self.t_overview)
        bar.pack(fill="x", pady=(0, 13))
        ttk.Button(bar, text="Сканировать устройство", style="Accent.TButton",
                   command=self.scan_device).pack(side="left")
        ttk.Button(bar, text="Сохранить отчёт JSON", command=self.save_report).pack(side="left", padx=8)
        ttk.Button(bar, text="Настройки телефона", command=lambda: self.run_device(
            "Открытие настроек Android", lambda: self.service.shell("am", "start", "-a", "android.settings.SETTINGS")))\
            .pack(side="left")
        ttk.Label(self.t_overview, text="Системные параметры и доступная диагностика ADB",
                  style="Muted.TLabel").pack(anchor="w", pady=(0, 8))
        self.diagnostic = tk.Text(self.t_overview, bg=CARD, fg=TEXT, font=("Consolas", 10),
                                  relief="flat", wrap="word", padx=18, pady=14,
                                  highlightthickness=1, highlightbackground=BORDER)
        self.diagnostic.pack(fill="both", expand=True)
        self.diagnostic.insert("1.0", "Подключите телефон, включите USB-отладку и подтвердите отпечаток RSA на экране Android.\n\n"
                               "Затем нажмите «Проверить устройства» и «Сканировать устройство».\n\n"
                               "Диагностика включает: Android, модель, сборка, процессор, батарея, RAM, хранилище, патч безопасности.")
        self.diagnostic.configure(state="disabled")

    def build_apps(self):
        top = ttk.Frame(self.t_apps)
        top.pack(fill="x", pady=(0, 12))
        ttk.Button(top, text="Сканировать установленные", style="Accent.TButton",
                   command=self.load_packages).pack(side="left")
        ttk.Button(top, text="Поиск рекламных наложений / автозапуска", command=self.check_flags).pack(side="left", padx=7)
        ttk.Button(top, text="Экспорт списка JSON", command=self.export_inventory).pack(side="left", padx=7)
        search_bar = ttk.Frame(self.t_apps)
        search_bar.pack(fill="x", pady=(0, 11))
        ttk.Label(search_bar, text="Поиск пакета:").pack(side="left")
        ttk.Entry(search_bar, textvariable=self.search_value, width=45).pack(side="left", padx=10)
        ttk.Label(search_bar, text="Ctrl/Shift — выбор нескольких строк", style="Muted.TLabel").pack(side="left")
        table_box = ttk.Frame(self.t_apps)
        table_box.pack(fill="both", expand=True)
        self.app_table = ttk.Treeview(table_box, columns=("package", "overlay", "boot"), show="headings",
                                      selectmode="extended")
        self.app_table.heading("package", text="Пакет установленного приложения")
        self.app_table.heading("overlay", text="Наложение окон*")
        self.app_table.heading("boot", text="Автозапуск*")
        self.app_table.column("package", width=510, anchor="w")
        self.app_table.column("overlay", width=130, anchor="center")
        self.app_table.column("boot", width=120, anchor="center")
        scroll = ttk.Scrollbar(table_box, orient="vertical", command=self.app_table.yview)
        self.app_table.configure(yscrollcommand=scroll.set)
        self.app_table.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.app_table.bind("<Double-1>", lambda _event: self.details())
        buttons = ttk.Frame(self.t_apps)
        buttons.pack(fill="x", pady=(12, 2))
        for title, callback in (("Сведения", self.details), ("Очистить кэш", lambda: self.bulk("cache")),
                                ("Остановить", lambda: self.bulk("stop")),
                                ("Отключить", lambda: self.bulk("disable")),
                                ("Включить", lambda: self.bulk("enable")),
                                ("Удалить", lambda: self.bulk("uninstall")),
                                ("Очистить данные", lambda: self.bulk("data"))):
            ttk.Button(buttons, text=title, command=callback).pack(side="left", padx=(0, 6))
        ttk.Label(self.t_apps, text="* Признак разрешения в манифесте, не доказательство рекламы или вредоносности. "
                                     "Операции подтверждаются владельцем.",
                  style="Muted.TLabel").pack(anchor="w", pady=(5, 0))

    def build_files(self):
        ttk.Label(self.t_files, text="Копирование между телефоном и ПК — без доступа к закрытым данным приложений",
                  style="Header.TLabel").pack(anchor="w", pady=(0, 13))
        self.folder_choice = tk.StringVar(value="Фото камеры")
        select = ttk.Frame(self.t_files)
        select.pack(fill="x", pady=(4, 9))
        ttk.Label(select, text="Папка Android:").pack(side="left")
        ttk.Combobox(select, textvariable=self.folder_choice, values=list(FILE_FOLDERS), state="readonly",
                     width=28).pack(side="left", padx=12)
        ttk.Button(select, text="Скопировать папку на ПК", style="Accent.TButton",
                   command=self.pull_folder).pack(side="left")
        buttons = ttk.Frame(self.t_files)
        buttons.pack(fill="x", pady=(12, 12))
        ttk.Button(buttons, text="Передать файлы с ПК на телефон", command=self.push_files).pack(side="left")
        ttk.Button(buttons, text="Извлечь APK приложения", command=self.pull_apk).pack(side="left", padx=8)
        ttk.Button(buttons, text="Список приложений (JSON)", command=self.export_inventory).pack(side="left")
        self.file_output = tk.Text(self.t_files, height=18, bg=CARD, fg=TEXT, font=("Consolas", 10),
                                   relief="flat", wrap="word", padx=16, pady=16)
        self.file_output.pack(fill="both", expand=True)
        self.file_output.insert("1.0", "Доступные каталоги: DCIM, Pictures, Download, Documents, Movies, Music, Android/media.\n\n"
                                    "ADB сохранит выбранный каталог со всем доступным содержимым.\n"
                                    "Можно передать локальные файлы в /sdcard/Download/AndroidControlHub/.\n\n"
                                    "Важно: /data/data, пароли, токены и базы данных других приложений не копируются.\n"
                                    "Для восстановления данных программ используйте штатные резервные копии Android и сервисы самих приложений.")
        self.file_output.configure(state="disabled")

    def build_tools(self):
        row1 = ttk.Frame(self.t_tools)
        row1.pack(fill="x", pady=(0, 14))
        ttk.Button(row1, text="Установить APK", style="Accent.TButton",
                   command=self.install_apk).pack(side="left")
        ttk.Button(row1, text="Установить split APK (несколько файлов)",
                   command=lambda: self.install_apk(multiple=True)).pack(side="left", padx=10)
        row2 = ttk.Frame(self.t_tools)
        row2.pack(fill="x", pady=(0, 14))
        ttk.Button(row2, text="Проверить Fastboot", command=self.scan_fastboot).pack(side="left")
        ttk.Button(row2, text="ADB версия", command=lambda: self.run_device(
            "Версия ADB", lambda: self.service.run("adb", ["version"]).combined, require_device=False))\
            .pack(side="left", padx=10)
        ttk.Button(row2, text="Fastboot версия", command=lambda: self.run_device(
            "Версия Fastboot", lambda: self.service.run("fastboot", ["--version"], check=False).combined,
            require_device=False)).pack(side="left")
        self.tools_output = tk.Text(self.t_tools, bg=CARD, fg=TEXT, font=("Consolas", 10), wrap="word",
                                    relief="flat", padx=16, pady=17)
        self.tools_output.pack(fill="both", expand=True)
        self.tools_output.insert("1.0", "Android APK: выберите файл, после установки Android проверит пакет и подпись.\n"
                                     "Split APK: выберите все части одной сборки; установка зависит от версии и подписи.\n\n"
                                     "Fastboot — только информация о подключении и параметрах. Разблокировка загрузчика, FRP-обход, "
                                     "прошивка и изменение IMEI здесь отсутствуют.\n\n"
                                     "Для ADB требуются официальные Android Platform Tools от Google.")
        self.tools_output.configure(state="disabled")

    def build_log(self):
        actions = ttk.Frame(self.t_log)
        actions.pack(fill="x", pady=(0, 10))
        ttk.Button(actions, text="Сохранить журнал", command=self.save_log).pack(side="left")
        ttk.Button(actions, text="Очистить отображение", command=self.clear_log).pack(side="left", padx=8)
        self.console = tk.Text(self.t_log, bg=CARD, fg=TEXT, font=("Consolas", 10), relief="flat",
                               wrap="word", padx=14, pady=12)
        self.console.pack(fill="both", expand=True)
        self.log("Запуск Windows Service Center. Данные отправляются только через локальный ADB владельца.")

    def log(self, message: str):
        stamp = time.strftime("%H:%M:%S")
        text = f"[{stamp}] {message}"
        self.log_lines.append(text)
        if hasattr(self, "console"):
            self.console.insert("end", text + "\n")
            self.console.see("end")

    def clear_log(self):
        self.console.delete("1.0", "end")
        self.log_lines.clear()

    def save_log(self):
        path = filedialog.asksaveasfilename(defaultextension=".txt", initialfile="AndroidHub-log.txt",
                                            filetypes=[("Текстовый журнал", "*.txt")])
        if path:
            Path(path).write_text("\n".join(self.log_lines), encoding="utf-8")
            messagebox.showinfo("Готово", "Журнал сохранён")

    def close(self):
        self.pool.shutdown(wait=False, cancel_futures=True)
        self.destroy()

    def busy_call(self, title, task, on_success=None, *, require_device=True):
        if self.running:
            messagebox.showwarning("Операция выполняется", "Дождитесь завершения текущего задания")
            return
        if require_device and not self.service.serial:
            messagebox.showwarning("Нет устройства", "Выберите авторизованный телефон (status=device)")
            return
        self.running = True
        self.state_value.set("Выполняется: " + title)
        self.log("→ " + title)
        def operation():
            try:
                return True, task()
            except Exception as exc:
                return False, str(exc)
        future = self.pool.submit(operation)
        def done(done_future):
            try:
                ok, result = done_future.result()
            except Exception as exc:
                ok, result = False, str(exc)
            def update():
                if not self.winfo_exists():
                    return
                self.running = False
                self.state_value.set("Завершено: " + title if ok else "Ошибка: " + title)
                self.log(("✓ " if ok else "✗ ") + title + "\n" + str(result)[:3500])
                if ok:
                    if on_success:
                        on_success(result)
                else:
                    messagebox.showerror("Ошибка операции", str(result)[:1600])
            try:
                self.after(0, update)
            except RuntimeError:
                pass
        future.add_done_callback(done)

    def run_device(self, title, fn, require_device=True):
        self.busy_call(title, fn, lambda result: self.set_output(self.tools_output, str(result)),
                       require_device=require_device)

    @staticmethod
    def set_output(widget: tk.Text, text: str):
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    def refresh_devices(self):
        def done(devices):
            self.devices_map = {str(d): d for d in devices}
            labels = list(self.devices_map)
            self.device_combo["values"] = labels
            active = next((label for label, d in self.devices_map.items() if d.serial == self.service.serial), None)
            if active:
                self.device_name.set(active)
            elif labels:
                self.device_name.set(labels[0]);self.select_device()
            else:
                self.device_name.set("Устройства не найдены")
            self.log("Устройств ADB: " + str(len(labels)))
            if any(d.status == "unauthorized" for d in devices):
                messagebox.showwarning("Не авторизовано", "Разблокируйте телефон и подтвердите запрос USB-отладки (RSA)")
        self.busy_call("Обнаружение ADB", self.service.devices, done, require_device=False)

    def select_device(self):
        item = self.devices_map.get(self.device_name.get())
        if not item:
            return
        if item.status != "device":
            self.service.serial = ""
            self.state_value.set(f"Телефон: {item.status} — требуется подтверждение на экране")
            return
        self.service.serial = item.serial
        self.state_value.set("Выбран: " + item.serial)
        self.log("Выбран USB/ADB: " + item.serial)

    def install_tools(self):
        if sys.platform != "win32":
            messagebox.showinfo("Windows", "Автоматическая установка Platform Tools предназначена для Windows.")
            return
        if not messagebox.askyesno("Android Platform Tools", "Скачать официальный пакет ADB/Fastboot по HTTPS с dl.google.com и установить в ваш профиль Windows?\n\nДля установки не нужны права администратора."):
            return
        def success(paths):
            self.adb_path.set(paths[0]);self.fastboot_path.set(paths[1])
            self.config_path.write_text(json.dumps({"adb": paths[0], "fastboot": paths[1]}, ensure_ascii=False), encoding="utf-8")
            messagebox.showinfo("Готово", "Официальные ADB и Fastboot установлены. Теперь подключите и авторизуйте телефон.")
            self.refresh_devices()
        self.busy_call("Загрузка Android Platform Tools с Google", self.service.install_platform_tools,
                       success, require_device=False)

    def tools_dialog(self):
        dialog = tk.Toplevel(self)
        dialog.title("ADB / Fastboot — пути")
        dialog.geometry("680x260")
        dialog.configure(bg=BG)
        dialog.transient(self)
        dialog.grab_set()
        frame = ttk.Frame(dialog, padding=20)
        frame.pack(fill="both", expand=True)
        for caption, var in (("adb.exe", self.adb_path), ("fastboot.exe", self.fastboot_path)):
            row = ttk.Frame(frame)
            row.pack(fill="x", pady=10)
            ttk.Label(row, text=caption, width=15).pack(side="left")
            ttk.Entry(row, textvariable=var, width=52).pack(side="left", padx=7)
            ttk.Button(row, text="Обзор", command=lambda v=var, c=caption: v.set(
                filedialog.askopenfilename(title=f"Найдите {c}", filetypes=[("EXE", "*.exe")]) or v.get()
            )).pack(side="left")
        def save():
            self.service.adb = self.adb_path.get().strip()
            self.service.fastboot = self.fastboot_path.get().strip()
            self.config_path.write_text(json.dumps({"adb": self.service.adb,
                                                   "fastboot": self.service.fastboot}, ensure_ascii=False), encoding="utf-8")
            dialog.destroy()
            self.refresh_devices()
        ttk.Button(frame, text="Сохранить и проверить", style="Accent.TButton", command=save).pack(anchor="w", pady=15)

    def scan_device(self):
        def success(report):
            self.last_report = report
            self.set_output(self.diagnostic, "\n\n".join(f"{key}\n{'─'*42}\n{value}" for key, value in report.items()))
        self.busy_call("Диагностика устройства", self.service.get_basic_report, success)

    def save_report(self):
        if not hasattr(self, "last_report"):
            messagebox.showinfo("Нет отчёта", "Сначала выполните диагностику")
            return
        filename = filedialog.asksaveasfilename(defaultextension=".json", initialfile="AndroidHub-report.json",
                                                filetypes=[("JSON", "*.json")])
        if filename:
            Path(filename).write_text(json.dumps(self.last_report, ensure_ascii=False, indent=2), encoding="utf-8")
            self.log("Сохранён отчёт: " + filename)

    def load_packages(self):
        def success(packages):
            self.current_packages = packages
            self.flagged_overlays.clear();self.flagged_boot.clear()
            self.render_packages()
            self.log("Найдено пользовательских приложений: " + str(len(packages)))
        self.busy_call("Список установленных приложений", self.service.third_party_packages, success)

    def render_packages(self):
        if not hasattr(self, "app_table"):
            return
        selected = set(self.app_table.selection())
        self.app_table.delete(*self.app_table.get_children())
        value = self.search_value.get().lower().strip()
        for package in self.current_packages:
            if value and value not in package.lower():
                continue
            self.app_table.insert("", "end", iid=package,
                                  values=(package, "Заявлено" if package in self.flagged_overlays else "—",
                                          "Заявлено" if package in self.flagged_boot else "—"))
        visible = self.app_table.get_children()
        self.app_table.selection_set([p for p in selected if p in visible])

    def check_flags(self):
        if not self.current_packages:
            messagebox.showinfo("Пока нет списка", "Сначала нажмите «Сканировать установленные»")
            return
        if not messagebox.askyesno("Расширенное сканирование",
                                   f"Проверить {len(self.current_packages)} пакетов? На это может уйти несколько минут.\n\n"
                                   "Разрешение на наложение окна НЕ означает показ рекламы."):
            return
        def progress(n, total):
            if n % 10 == 0 or n == total:
                try: self.after(0, lambda: self.state_value.set(f"Анализ пакетов: {n}/{total}"))
                except RuntimeError: pass
        def task():
            return self.service.list_overlay_candidates(self.current_packages, progress)
        def done(flags):
            self.flagged_overlays, self.flagged_boot = flags
            self.render_packages()
            self.log(f"Признаки наложения: {len(flags[0])}; автозапуска: {len(flags[1])}")
        self.busy_call("Проверка разрешений приложений", task, done)

    def selected_packages(self):
        values = [self.app_table.set(item, "package") for item in self.app_table.selection()]
        if not values:
            messagebox.showinfo("Выберите приложение", "Отметьте строку или несколько строк в таблице")
        return values

    def details(self):
        targets = self.selected_packages()
        if not targets:
            return
        self.busy_call("Сведения о " + targets[0], lambda: self.service.package_details(targets[0]),
                       lambda s: messagebox.showinfo("Пакет: " + targets[0], str(s)[:3200]))

    def bulk(self, mode):
        pkgs = self.selected_packages()
        if not pkgs:
            return
        names = {"cache":"Очистить только кэш", "data":"УДАЛИТЬ ВСЕ ДАННЫЕ",
                 "disable":"Отключить", "enable":"Включить", "stop":"Остановить", "uninstall":"Удалить для профиля"}
        desc = names[mode]
        preview = "\n".join(f"• {p}" for p in pkgs[:35])
        if len(pkgs) > 35:
            preview += f"\n…ещё {len(pkgs)-35}"
        suffix = "\n\nПАРОЛИ, НАСТРОЙКИ И ЛОКАЛЬНЫЕ ДАННЫЕ МОГУТ БЫТЬ УТЕРЯНЫ." if mode in ("data", "uninstall") else ""
        if not messagebox.askyesno(f"Подтверждение: {desc}",
                                   f"{desc} для {len(pkgs)} приложений?\n\n{preview}{suffix}\n\n"
                                   "Системные программы исключаются автоматически."):
            return
        if mode in ("data", "uninstall"):
            required = "ОЧИСТИТЬ" if mode == "data" else "УДАЛИТЬ"
            answer = simpledialog.askstring("Подтверждение владельца", f"Введите {required}, чтобы продолжить:", parent=self)
            if answer != required:
                messagebox.showinfo("Отменено", "Операция не начата")
                return
        def do():
            successes, failures = [], []
            for pkg in pkgs:
                try:
                    successes.append((pkg, self.service.maintenance(pkg, mode)))
                except Exception as exc:
                    failures.append((pkg, str(exc)))
            return successes, failures
        def done(res):
            successes, failures = res
            for pkg, result in successes:
                self.log(f"{desc}: {pkg} → {result[:320]}")
            for pkg, error in failures:
                self.log(f"ОШИБКА {pkg}: {error}")
            messagebox.showinfo("Результат обслуживания",
                                f"Действие: {desc}\nУспешно: {len(successes)}\nС ошибкой: {len(failures)}\n\n"
                                "Подробности в журнале. Проверяйте состояние приложений на телефоне.")
            if mode in ("uninstall", "disable", "enable"):
                self.load_packages()
        self.busy_call(desc, do, done)

    def export_inventory(self):
        path = filedialog.asksaveasfilename(defaultextension=".json", initialfile="AndroidHub-apps.json",
                                            filetypes=[("JSON", "*.json")])
        if path:
            self.busy_call("Экспорт списка приложений", lambda: self.service.export_inventory(path),
                           lambda n: messagebox.showinfo("Сохранено", f"Экспортировано пакетов: {n}"))

    def pull_folder(self):
        remote = FILE_FOLDERS[self.folder_choice.get()]
        target = filedialog.askdirectory(title="Куда сохранить данные телефона на ПК?")
        if not target:
            return
        if not messagebox.askyesno("Резервная копия", f"Копировать {remote} в папку ПК?\n{target}\n\n"
                                   "При большом объёме процедура может занять длительное время."):
            return
        self.busy_call("Копирование " + remote, lambda: self.service.pull_folder(remote, target),
                       lambda text: self.set_output(self.file_output, str(text)))

    def push_files(self):
        paths = list(filedialog.askopenfilenames(title="Выберите файлы для передачи на телефон"))
        if not paths:
            return
        if not messagebox.askyesno("Передача файлов", f"Передать файлов: {len(paths)}?\n"
                                   "Назначение: /sdcard/Download/AndroidControlHub/\n\n"
                                   "Существующие файлы с теми же именами могут быть перезаписаны."):
            return
        self.busy_call("Передача файлов на телефон", lambda: self.service.push_files(paths),
                       lambda out: self.set_output(self.file_output, "\n\n".join(out)))

    def pull_apk(self):
        package = simpledialog.askstring("APK приложения", "Введите имя пакета (пример: com.example.app)", parent=self)
        if not package:
            return
        target = filedialog.askdirectory(title="Куда извлечь APK-файлы?")
        if target:
            self.busy_call("Экспорт APK " + package, lambda: self.service.export_apk(package, target),
                           lambda paths: self.set_output(self.file_output, "Файлы:\n" + "\n".join(paths)))

    def install_apk(self, multiple=False):
        paths = list(filedialog.askopenfilenames(title="Выберите APK-файлы",
                                                 filetypes=[("Android APK", "*.apk")]))
        if not paths:
            return
        if not multiple and len(paths) > 1:
            messagebox.showwarning("Несколько APK", "Для установки split APK выберите соответствующую кнопку")
            return
        if not messagebox.askyesno("Установка APK", f"Установить {len(paths)} APK-файлов на выбранный телефон?\n\n"
                                   "Подпись и совместимость проверяет Android. APK скачивайте только из доверенных источников."):
            return
        self.run_device("Установка APK", lambda: self.service.install_apk(paths))

    def scan_fastboot(self):
        self.busy_call("Fastboot диагностика", self.service.fastboot_summary,
                       lambda result: self.set_output(self.tools_output, str(result)), require_device=False)


if __name__ == "__main__":
    App().mainloop()
